const request = require("supertest");
const createServer = require("./src/server");

let app;
beforeAll(() => {
  app = createServer();
});

describe("Survey API - sample", () => {
  test("GET /surveys returns 200", async () => {
    const res = await request(app).get("/surveys");
    expect(res.statusCode).toBe(200);
  });
});
