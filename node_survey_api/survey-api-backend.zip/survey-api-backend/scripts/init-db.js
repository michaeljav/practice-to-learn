const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const dbFile = path.join(__dirname, '..', 'db.sqlite');
const schemaFile = path.join(__dirname, '..', 'db', 'init.sql');

const schema = fs.readFileSync(schemaFile, 'utf-8');
const db = new sqlite3.Database(dbFile);

db.serialize(() => {
  db.exec(schema, (err) => {
    if (err) {
      console.error('Error applying schema:', err.message);
      process.exit(1);
    } else {
      console.log('Schema applied successfully.');
      db.run('INSERT OR IGNORE INTO surveys (id, title) VALUES (?, ?)', [1, 'Initial Survey'], (e2) => {
        if (e2) console.error('Seed error:', e2.message);
        else console.log('Seeded surveys table.');
        db.close();
      });
    }
  });
});
