const express = require('express');
const router = express.Router();

// Storage mode: in-memory (default) or SQLite (USE_SQLITE=1)
const useSqlite = String(process.env.USE_SQLITE || '0') === '1';
let surveys = []; // in-memory fallback

let db = null;
if (useSqlite) {
  db = require('./db'); // opened sqlite3 Database
}

/**
 * GET /surveys
 */
router.get('/surveys', (req, res) => {
  if (!useSqlite) {
    return res.status(200).json(surveys);
  }
  db.all('SELECT id, title FROM surveys ORDER BY id ASC', [], (err, rows) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err.message });
    return res.status(200).json(rows);
  });
});

/**
 * POST /surveys
 * { id: <integer>, title: <string> }
 */
router.post('/surveys', (req, res) => {
  const { id, title } = req.body || {};
  if (id === undefined || typeof title !== 'string') {
    return res.status(400).json({ message: 'Invalid survey payload' });
    }
  if (!useSqlite) {
    const survey = { id, title };
    surveys.push(survey);
    return res.status(201).json(survey);
  }
  db.run('INSERT INTO surveys (id, title) VALUES (?, ?)', [id, title], function (err) {
    if (err) return res.status(500).json({ message: 'DB error', error: err.message });
    return res.status(201).json({ id, title });
  });
});

/**
 * PUT /surveys/:id
 * { id?: <integer>, title?: <string> }
 */
router.put('/surveys/:id', (req, res) => {
  const paramId = req.params.id;
  const { id: bodyId, title } = req.body || {};

  if (!useSqlite) {
    const idx = surveys.findIndex((s) => String(s.id) === String(paramId));
    if (idx === -1) return res.status(404).json({ message: 'Survey not found' });
    if (bodyId !== undefined) surveys[idx].id = bodyId;
    if (typeof title === 'string') surveys[idx].title = title;
    return res.status(200).json(surveys[idx]);
  }

  db.get('SELECT id, title FROM surveys WHERE id = ?', [paramId], (err, row) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err.message });
    if (!row) return res.status(404).json({ message: 'Survey not found' });

    const newId = bodyId !== undefined ? bodyId : row.id;
    const newTitle = typeof title === 'string' ? title : row.title;

    db.run('UPDATE surveys SET id = ?, title = ? WHERE id = ?', [newId, newTitle, paramId], function (err2) {
      if (err2) return res.status(500).json({ message: 'DB error', error: err2.message });
      return res.status(200).json({ id: newId, title: newTitle });
    });
  });
});

/**
 * DELETE /surveys/:id
 */
router.delete('/surveys/:id', (req, res) => {
  const paramId = req.params.id;

  if (!useSqlite) {
    const idx = surveys.findIndex((s) => String(s.id) === String(paramId));
    if (idx === -1) return res.status(404).json({ message: 'Survey not found' });
    const [deleted] = surveys.splice(idx, 1);
    return res.status(200).json(deleted);
  }

  db.get('SELECT id, title FROM surveys WHERE id = ?', [paramId], (err, row) => {
    if (err) return res.status(500).json({ message: 'DB error', error: err.message });
    if (!row) return res.status(404).json({ message: 'Survey not found' });

    db.run('DELETE FROM surveys WHERE id = ?', [paramId], function (err2) {
      if (err2) return res.status(500).json({ message: 'DB error', error: err2.message });
      return res.status(200).json(row);
    });
  });
});

module.exports = router;
