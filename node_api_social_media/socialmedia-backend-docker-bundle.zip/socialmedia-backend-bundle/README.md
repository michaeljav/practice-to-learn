# Social Media API (Node.js + SQLite) – Docker & Local Setup

This bundle lets you run your **SocialMediaApiSkeleton/backend** either **locally** or via **Docker**.
It also includes instructions to **create `db.sqlite`** from scratch and to **debug** with VS Code.

> Server port: **8000** (tests use 5000 automatically when `NODE_ENV=test`).

---

## 1) Project Structure (expected)
```
backend/
  index.js
  routes.js
  database.js
  package.json
  tests/
    sample.test.js
```
You can drop these files into `backend/` of your project. The bundle adds Docker + helper files.

---

## 2) Quick Start (Local)

### Requirements
- Node.js **18+**
- npm **8+**
- **sqlite3** command (optional, only if you want to build `db.sqlite` manually)

### Install & run
```bash
cd backend
npm install
npm run sample_tests   # optional: runs sample.test.js
npm start              # starts dev server with nodemon on http://localhost:8000
```

### Create `db.sqlite` (two options)

**Option A – Auto by the app (recommended):**  
`database.js` auto-creates tables and seeds rows on first run. Just start the app:
```bash
npm start
```
You should see logs like "Connected to the SQLite database. User Table present", etc.

**Option B – Create from SQL:**
Use the provided SQL:
```bash
# from the backend/ folder where you want db.sqlite to live
sqlite3 db.sqlite < scripts/init-db.sql
```
If `sqlite3` is not installed, install it using your OS package manager (e.g. `sudo apt-get install sqlite3`).

**Option C – Using helper script (Linux/macOS):**
```bash
bash scripts/create-db.sh
```

---

## 3) Quick Start (Docker)

### Build & run (with hot reload)
```bash
# from backend/
docker compose up --build
# App runs at http://localhost:8000
```

- The container uses **nodemon** for live-reload when you edit local files.
- The working directory `/app` is bind-mounted from your local project.

### Stop
```bash
docker compose down
```

---

## 4) VS Code Debugging

A ready-to-use **.vscode/launch.json** is included for attaching to the Node process (port 9229).

### Local attach
1. Start the server in inspect mode:
   ```bash
   NODE_OPTIONS=--inspect=0.0.0.0:9229 npm start
   ```
2. In VS Code, run **Run and Debug → Attach (Node:9229)**

### Docker attach
1. Edit `docker-compose.yml` to uncomment the `NODE_OPTIONS=--inspect=0.0.0.0:9229` env line.
2. `docker compose up --build`
3. In VS Code, run **Attach (Node:9229)**

---

## 5) API Endpoints (as per exercise)

- `GET /api/user/<built-in function id>` – user profile with followers/following counts
- `GET /api/posts` – all posts sorted by time (ascending)
- `GET /api/posts/<built-in function id>` – single post with likes and comments
- `POST /api/posts` – add post (body: `image`, `description`, author defaults to user id 1)
- `PUT /api/posts/<built-in function id>` – update post
- `DELETE /api/posts/<built-in function id>` – delete post
- `POST /api/follow/<built-in function id>` – follow user (from user id 1)
- `POST /api/unfollow/<built-in function id>` – unfollow user (from user id 1)
- `POST /api/like/<built-in function id>` – like post (by user id 1)
- `POST /api/unlike/<built-in function id>` – unlike post (by user id 1)
- `POST /api/comment/<built-in function id>` – add a comment to a post (by user id 1)

> **404 format:** `{ "Error": "Not found" }`

---

## 6) cURL smoke tests

```bash
curl http://localhost:8000/api/posts
curl http://localhost:8000/api/posts/1

curl -X POST http://localhost:8000/api/posts   -H "Content-Type: application/json"   -d '{"image":"Unit test image","description":"Unit test"}'

curl -X PUT http://localhost:8000/api/posts/1   -H "Content-Type: application/json"   -d '{"image":"Updated","description":"Updated desc"}'

curl -X POST http://localhost:8000/api/like/1
curl -X POST http://localhost:8000/api/unlike/1
curl -X POST http://localhost:8000/api/follow/2
curl -X POST http://localhost:8000/api/unfollow/2

curl -X POST http://localhost:8000/api/comment/1   -H "Content-Type: application/json"   -d '{"comment":"Nice!"}'
```

---

## 7) Troubleshooting

- **Tests timing out** → Make sure `routes.js` is filled (see earlier message) and `GET /api/posts` orders by `ASC`.
- **`SQLITE_BUSY`** → Close other processes locking the DB or move `db.sqlite` to a writable location.
- **Port already in use** → Change `HTTP_PORT` in `index.js` or map another host port in docker-compose.

---

## 8) License
MIT (or your project’s default)
