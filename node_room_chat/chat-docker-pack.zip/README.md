# Chat App – Local & Docker Setup

This pack adds **Docker** support and a clear **README** so you can run the project either **locally** or **in Docker**, plus VS Code debugging. It also includes the **exercise instructions** summarized at the end.

> Project structure expected by this README:
>
> ```
> repo-root/
> ├── backend/        # Express + Socket.IO code (run.js, server.js, app.js, utils/, route/, tests/ ...)
> └── frontend/       # Static assets and views used by the backend (public/, partial/, etc.)
> ```

---

## 0) One-time fixes (important)
The frontend file `frontend/public/js/setconnection.js` must use **backticks** for the template string in the `io(...)` call and for `location.href`. Use this exact snippet for the first lines:

```js
const { username, room } = Qs.parse(location.search, { ignoreQueryPrefix: true });

const socket = io(
  `${window.location.protocol}//${window.location.host}`,
  { path: `/${window.location.pathname.split("/")[1]}/socket.io` }
);

socket.emit("join", { username, room }, (error) => {
  if (error) {
    alert(error);
    location.href = `${window.location.protocol}//${window.location.host}/${window.location.pathname.split("/")[1]}/`;
  }
});
```

---

## 1) Run Locally (no Docker)

### Install & Test
```bash
cd backend
npm install
npm run sample_tests
```

### Start (development – hot reload)
```bash
npm run dev
```
Open the Preview/Browser at `http://localhost:8000/`

### Start (production)
```bash
npm start
```

### Debug locally (VS Code)
1. Run the app with an inspector:
   ```bash
   node --inspect=0.0.0.0:9229 run.js
   ```
   or add a script to `package.json`:
   ```json
   "debug": "node --inspect=0.0.0.0:9229 run.js"
   ```
   then `npm run debug`.

2. Use the provided **.vscode/launch.json** (see below) → *Run and Debug* → **Attach to Node (9229)**.

---

## 2) Run with Docker

> Ensure that the **Docker build context** is the repo root (where `backend/` and `frontend/` live).

### Build production image
```bash
docker build -t chat-app:prod .
```

### Run production container
```bash
docker run --rm -p 8000:8000 --name chat chat-app:prod
```
Visit `http://localhost:8000/`.

### Development with hot reload (docker-compose)
```bash
docker compose up --build
```
This mounts your local `backend/` and `frontend/` into the container and runs `npm run dev` (nodemon).

> **Tip:** If you want to debug inside Docker, start your app with `node --inspect=0.0.0.0:9229 run.js` or add a `dev:debug` script. Then attach from VS Code (config below).

---

## 3) VS Code Debug Configs

The pack includes `.vscode/launch.json` with two configurations:
- **Attach to Node (9229)**: works locally or inside Docker if port 9229 is exposed.
- **Launch via NPM (debug)**: runs `npm run debug` locally.

---

## 4) Exercise Requirements Recap (from prompt)

**Goal:** Build a chat application where users can create rooms, join rooms, and have conversations.

**Tech stack**
- Backend: Node.js
- Port: 8000

**Inputs (Join page)**
- Username
- Room name

**Functionality**
- Enter a specific chat room to communicate with other users.
- Send a live location to every user.

**Server behaviors**
- On **join**: show “_username has joined_” to the room with a timestamp.
- On **message**: broadcast message with username and timestamp; **block profanity** (using `bad-words`).
- On **location**: broadcast a Google Maps link built from the sender’s coordinates.
- On **disconnect**: show “_username has left_” to the room with a timestamp.
- Use `frontend/public/js/setconnection.js` as a reference for the client-side socket code.

**Testing**
- From `/backend`:
  ```bash
  npm run sample_tests
  ```

**Submission notes (from IDE)**
- Use the Terminal for additional commands.
- “Run code” compiles sample tests (no score).
- “Submit code” runs main tests (scored).

---

## 5) Common Troubleshooting

- If frontend assets don’t load in Docker, ensure both `frontend/` and `backend/` are present in the container (this Dockerfile copies both).  
- Make sure template strings in `setconnection.js` use **backticks** (`` ` ``) not quotes.
- If hot reload doesn’t trigger in Docker on Windows, try adding in `docker-compose.yml`:
  ```yaml
  volumes:
    - ./backend:/app/backend:cached
    - ./frontend:/app/frontend:cached
  ```

---

## 6) File list included in this pack
- `Dockerfile`
- `docker-compose.yml`
- `.dockerignore`
- `.vscode/launch.json`
- `README.md` (this file)

Place these at the **repo root**, next to the `backend/` and `frontend/` directories.
