const express = require("express");
const cors = require("cors");
const routes = require("./routes");

const createServer = () => {
  const app = express();
  app.use(
    cors({
      origin: "*",
      methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    })
  );
  app.use(express.json());
  app.use("/", routes);
  return app;
};

module.exports = createServer;
