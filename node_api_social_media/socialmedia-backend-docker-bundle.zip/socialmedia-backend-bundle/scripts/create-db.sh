#!/usr/bin/env bash
set -euo pipefail

DB_FILE="db.sqlite"
SQL_FILE="scripts/init-db.sql"

if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "sqlite3 not found. Please install it (e.g., apt-get install sqlite3)"
  exit 1
fi

echo "Creating ${DB_FILE} from ${SQL_FILE} ..."
sqlite3 "${DB_FILE}" < "${SQL_FILE}"
echo "Done. You can now run: npm start"
