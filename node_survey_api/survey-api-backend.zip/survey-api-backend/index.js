const createServer = require("./src/server");
const app = createServer();
const port = process.env.PORT || process.env.port || 8000;

app.listen(port, () => console.log("server is running at port " + port));
