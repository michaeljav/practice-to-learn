# NodeJS Survey API (Docker + Local + SQLite)

This repository contains a **Node.js + Express** backend that implements the *Survey API* exercise from your screenshots.
It supports **two storage modes**:

- **In-memory** (default) — super simple, volatile storage.
- **SQLite** (optional) — persistence using a local `db.sqlite` file.

---

## Exercise Requirements (as in the images)

Implement API routes in `src/routes.js` using in‑memory storage (and here we also support SQLite via `USE_SQLITE=1`):

- **GET `/surveys`** — return all surveys as JSON.
- **POST `/surveys`** — accept a survey in the form `{ id: <integer>, title: <string> }`, push it to the list, and return **201** with the created survey.
- **PUT `/surveys/:id`** — accept `{ id?: <integer>, title?: <string> }`, update the existing survey, return the updated survey or **404** if not found.
- **DELETE `/surveys/:id`** — delete the survey by `id`, return the deleted survey or **404** if not found.

**Testing instructions from the exercise:**

- Use the Terminal to run commands (example: navigate to `backend` and run `npm run sample_tests`).
- Clicking **Run code** (or equivalent) compiles and runs sample tests (in this package, `npm run sample_tests` does that locally).
- Clicking **Submit code** (on your platform) runs multiple tests.

Port: **8000**

---

## Project Structure

```text
survey-api-backend/
├─ index.js
├─ package.json
├─ nodemon.json
├─ Dockerfile
├─ docker-compose.yml
├─ .dockerignore
├─ README.md
├─ db.sqlite                 # created by init script (SQLite mode)
├─ db/
│   └─ init.sql
├─ scripts/
│   └─ init-db.js
├─ src/
│   ├─ server.js
│   ├─ routes.js
│   └─ db.js                 # only used when USE_SQLITE=1
└─ .vscode/
    └─ launch.json           # optional VS Code debugger attach
```

---

## Run Locally (In‑Memory) — Quick Start

```bash
npm install
npm run sample_tests    # optional: runs provided sample test (GET /surveys => 200)
npm start               # starts on http://localhost:8000
```

**Try the endpoints:**

```bash
# List surveys (expected [] at start)
curl http://localhost:8000/surveys

# Create
curl -X POST http://localhost:8000/surveys -H "Content-Type: application/json"       -d '{"id":1,"title":"Customer Satisfaction 2025"}'

# Update
curl -X PUT http://localhost:8000/surveys/1 -H "Content-Type: application/json"       -d '{"title":"Updated Title"}'

# Delete
curl -X DELETE http://localhost:8000/surveys/1
```

---

## Run Locally (SQLite persistence)

1) Install dependencies:
```bash
npm install
```

2) Create/initialize the database:
```bash
node scripts/init-db.js
```

3) Start the server with SQLite enabled:
```bash
USE_SQLITE=1 npm start
```

**Where is the DB?**
- The file is `db.sqlite` at the project root.
- The schema lives in `db/init.sql`:
  ```sql
  CREATE TABLE IF NOT EXISTS surveys (
    id INTEGER PRIMARY KEY,
    title TEXT NOT NULL
  );
  ```

---

## Docker (with optional SQLite persistence)

Build & run:
```bash
docker compose up --build
```

- By default this runs **in‑memory** mode.
- To enable SQLite in Docker:
  1. Open `docker-compose.yml`
  2. Uncomment the environment variable `USE_SQLITE=1`
  3. (Optional) Uncomment the volume mapping for `surveydb` to persist the file across restarts.

The API will be available at **http://localhost:8000**.

---

## Debugging

### Nodemon
We use `nodemon` for auto-restart during development (`npm start`).

### Node Inspector (optional)
To enable the inspector locally:
```bash
NODE_OPTIONS="--inspect=0.0.0.0:9229" npm start
```
Then attach from VS Code to **localhost:9229** using the provided `.vscode/launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "type": "node",
      "request": "attach",
      "name": "Attach to Node",
      "address": "localhost",
      "port": 9229,
      "restart": true,
      "protocol": "inspector"
    }
  ]
}
```

### Docker + Inspector (optional)
In `docker-compose.yml`, you can map `9229:9229` and start with:
```yaml
# command: sh -c "NODE_OPTIONS=--inspect=0.0.0.0:9229 npm start"
```

---

## Scripts

- `npm start` — dev server with `nodemon`
- `npm run sample_tests` — runs a minimal Supertest sample (GET /surveys => 200)
- `node scripts/init-db.js` — creates/initializes SQLite database

---

## Environment Variables

- `PORT` (default: `8000`)
- `USE_SQLITE`
  - `0` or unset — in‑memory storage (default)
  - `1` — use SQLite storage

---

## Notes

- The SQLite mode is **optional** — the original exercise only required in‑memory storage.
- Both modes share the same HTTP API, so your tests for the exercise still pass.
