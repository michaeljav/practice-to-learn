-- Drop & Create schema, then seed, matching database.js
PRAGMA foreign_keys=OFF;

DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS post;
DROP TABLE IF EXISTS likes;
DROP TABLE IF EXISTS follows;
DROP TABLE IF EXISTS comments;

CREATE TABLE user (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  bio  TEXT
);

CREATE TABLE post (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  image TEXT,
  description TEXT,
  user INTEGER,
  createdAt DATETIME,
  FOREIGN KEY(user) REFERENCES user(id)
);

CREATE TABLE likes (
  userid INTEGER,
  postid INTEGER,
  FOREIGN KEY(userid) REFERENCES user(id),
  FOREIGN KEY(postid) REFERENCES post(id)
);

CREATE TABLE follows (
  from_user INTEGER,
  to_user   INTEGER,
  FOREIGN KEY(from_user) REFERENCES user(id),
  FOREIGN KEY(to_user)   REFERENCES user(id)
);

CREATE TABLE comments (
  comment TEXT,
  userid  INTEGER,
  postid  INTEGER,
  FOREIGN KEY(userid) REFERENCES user(id),
  FOREIGN KEY(postid) REFERENCES post(id)
);

-- Seed users
INSERT INTO user (id, name, bio) VALUES (1, 'Test User 1', 'Test bio');
INSERT INTO user (id, name, bio) VALUES (2, 'Test User 2', 'Test bio 2');
INSERT INTO user (id, name, bio) VALUES (3, 'Test User 3', 'Test bio 3');

-- Seed posts
INSERT INTO post (id, image, description, user, createdAt)
VALUES (1, 'Test image url', 'Test description 1', 2, '2021-09-16 16:00:00');
INSERT INTO post (id, image, description, user, createdAt)
VALUES (2, 'Test image url 2', 'Test description 2', 3, '2021-09-16 17:00:00');

-- Optional example follows (same as database.js)
INSERT INTO follows (from_user, to_user) VALUES (2, 3);
INSERT INTO follows (from_user, to_user) VALUES (3, 2);

-- Leave likes/comments empty by default so tests expect 0/[]
